import { DashboardShell } from "@/components/dashboard-shell"
import { AccountsTable } from "@/components/accounts-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function AccountsPage() {
  return (
    <DashboardShell>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-2">
            <h1 className="text-balance text-3xl font-bold">Accounts</h1>
            <p className="text-pretty text-muted-foreground">Manage your financial accounts</p>
          </div>
          <Button>
            <Plus className="mr-2 size-4" />
            Create Account
          </Button>
        </div>

        <AccountsTable />
      </div>
    </DashboardShell>
  )
}
