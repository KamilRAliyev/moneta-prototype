import { DashboardShell } from "@/components/dashboard-shell"
import { TransactionsTable } from "@/components/transactions-table"
import { TransactionsFilters } from "@/components/transactions-filters"

export default function TransactionsPage() {
  return (
    <DashboardShell>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-balance text-3xl font-bold">Transactions</h1>
          <p className="text-pretty text-muted-foreground">View and manage ingested transaction data</p>
        </div>

        <TransactionsFilters />
        <TransactionsTable />
      </div>
    </DashboardShell>
  )
}
