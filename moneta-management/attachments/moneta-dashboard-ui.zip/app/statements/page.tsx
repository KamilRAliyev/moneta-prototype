import { DashboardShell } from "@/components/dashboard-shell"
import { StatementsUpload } from "@/components/statements-upload"
import { StatementsTable } from "@/components/statements-table"

export default function StatementsPage() {
  return (
    <DashboardShell>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-balance text-3xl font-bold">Statements</h1>
          <p className="text-pretty text-muted-foreground">Upload and manage CSV statement files for your accounts</p>
        </div>

        <StatementsUpload />
        <StatementsTable />
      </div>
    </DashboardShell>
  )
}
