"use client"
import { Upload } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function StatementsUpload() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Statement</CardTitle>
        <CardDescription>Select an account and upload a CSV file</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          <Label htmlFor="account">Account *</Label>
          <Select>
            <SelectTrigger id="account">
              <SelectValue placeholder="Select an account..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="chase-cred">Chase cred</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2">
          <Label>CSV File *</Label>
          <div className="flex cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/25 p-12 transition-colors hover:border-muted-foreground/50">
            <div className="flex flex-col items-center gap-2 text-center">
              <Upload className="size-8 text-muted-foreground" />
              <div className="flex flex-col gap-1">
                <p className="text-sm font-medium">Click to upload or drag and drop</p>
                <p className="text-xs text-muted-foreground">CSV files only (max 50MB)</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button>Upload Statement</Button>
        </div>
      </CardContent>
    </Card>
  )
}
