"use client"

import * as React from "react"
import { Settings, Trash2 } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"

const transactions = [
  {
    insertedAt: "12/27/2025, 12:56:56 AM",
    account: "Chase cred",
    statement: "Chase6490_Activity20240901_20251012_20251012.CSV",
    amount: 500,
    category: "-",
    description: "Payment Thank You-Mobile",
    postDate: "9/11/2024",
    transactionDate: "9/11/2024",
    type: "Payment",
  },
  {
    insertedAt: "12/27/2025, 12:56:56 AM",
    account: "Chase cred",
    statement: "Chase6490_Activity20240901_20251012_20251012.CSV",
    amount: -24.54,
    category: "Food & Drink",
    description: "DD *DOORDASH KINGSTERI",
    postDate: "9/9/2024",
    transactionDate: "9/8/2024",
    type: "Sale",
  },
  {
    insertedAt: "12/27/2025, 12:56:56 AM",
    account: "Chase cred",
    statement: "Chase6490_Activity20240901_20251012_20251012.CSV",
    amount: -25.96,
    category: "Travel",
    description: "UBER *TRIP",
    postDate: "9/15/2024",
    transactionDate: "9/14/2024",
    type: "Sale",
  },
  {
    insertedAt: "12/27/2025, 12:56:56 AM",
    account: "Chase cred",
    statement: "Chase6490_Activity20240901_20251012_20251012.CSV",
    amount: -5.93,
    category: "Food & Drink",
    description: "TST* MACQUARIE NY CAFE",
    postDate: "9/12/2024",
    transactionDate: "9/11/2024",
    type: "Sale",
  },
]

export function TransactionsTable() {
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800)
    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Transactions</CardTitle>
          </div>
        </CardHeader>
        <div className="p-6 pt-0">
          <div className="flex flex-col gap-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex gap-4">
                <Skeleton className="h-10 flex-1" />
                <Skeleton className="h-10 w-24" />
              </div>
            ))}
          </div>
        </div>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Transactions</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Settings className="mr-2 size-4" />
              Column Settings
            </Button>
            <Button variant="destructive" size="sm">
              <Trash2 className="mr-2 size-4" />
              Remove All Transactions
            </Button>
          </div>
        </div>
      </CardHeader>
      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Inserted At</TableHead>
              <TableHead>Account</TableHead>
              <TableHead>Statement</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Post Date</TableHead>
              <TableHead>Transaction Date</TableHead>
              <TableHead>Type</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((transaction, index) => (
              <TableRow key={index}>
                <TableCell className="whitespace-nowrap">{transaction.insertedAt}</TableCell>
                <TableCell>{transaction.account}</TableCell>
                <TableCell className="max-w-[300px] truncate">{transaction.statement}</TableCell>
                <TableCell className="text-right font-medium">
                  <span
                    className={
                      transaction.amount < 0 ? "text-red-600 dark:text-red-400" : "text-green-600 dark:text-green-400"
                    }
                  >
                    {transaction.amount < 0 ? `-$${Math.abs(transaction.amount)}` : `$${transaction.amount}`}
                  </span>
                </TableCell>
                <TableCell>
                  {transaction.category !== "-" ? (
                    <Badge variant="outline">{transaction.category}</Badge>
                  ) : (
                    transaction.category
                  )}
                </TableCell>
                <TableCell>{transaction.description}</TableCell>
                <TableCell className="whitespace-nowrap">{transaction.postDate}</TableCell>
                <TableCell className="whitespace-nowrap">{transaction.transactionDate}</TableCell>
                <TableCell>
                  <Badge variant="outline">{transaction.type}</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  )
}
