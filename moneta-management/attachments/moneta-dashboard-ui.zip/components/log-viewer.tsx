"use client"

import * as React from "react"
import { X, RefreshCw, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface LogViewerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const sampleLogs = [
  { timestamp: "2025-12-27 09:39:59", level: "info", message: "API health check passed" },
  { timestamp: "2025-12-27 09:35:12", level: "success", message: "Statement uploaded successfully" },
  { timestamp: "2025-12-27 09:34:45", level: "info", message: "Processing CSV file: Chase6490_Activity.csv" },
  { timestamp: "2025-12-27 09:30:22", level: "info", message: "User authenticated" },
  { timestamp: "2025-12-27 09:25:11", level: "warning", message: "Slow query detected: transactions table" },
  { timestamp: "2025-12-27 09:20:05", level: "info", message: "Database connection established" },
]

export function LogViewer({ open, onOpenChange }: LogViewerProps) {
  const [logs, setLogs] = React.useState(sampleLogs)

  const handleClear = () => {
    setLogs([])
  }

  const handleRefresh = () => {
    setLogs(sampleLogs)
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          "fixed inset-0 z-50 bg-black/50 transition-opacity",
          open ? "opacity-100" : "pointer-events-none opacity-0",
        )}
        onClick={() => onOpenChange(false)}
      />

      {/* Panel */}
      <div
        className={cn(
          "bg-background fixed right-0 top-0 z-50 h-full w-full border-l shadow-lg transition-transform duration-300 ease-in-out sm:w-[480px]",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center justify-between border-b p-4">
            <div className="flex flex-col gap-1">
              <h2 className="text-lg font-semibold">System Logs</h2>
              <p className="text-sm text-muted-foreground">Real-time application logs</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="size-8">
              <X className="size-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 border-b p-4">
            <Button variant="outline" size="sm" onClick={handleRefresh} className="gap-2 bg-transparent">
              <RefreshCw className="size-3.5" />
              Force Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={handleClear} className="gap-2 bg-transparent">
              <Trash2 className="size-3.5" />
              Clear
            </Button>
          </div>

          {/* Logs */}
          <ScrollArea className="flex-1 p-4">
            <div className="flex flex-col gap-2">
              {logs.length === 0 ? (
                <div className="flex h-[400px] items-center justify-center">
                  <p className="text-sm text-muted-foreground">No logs available</p>
                </div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="rounded-lg border bg-card p-3 text-sm">
                    <div className="mb-1 flex items-center gap-2">
                      <span
                        className={cn(
                          "inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium",
                          log.level === "error" && "bg-red-500/10 text-red-600 dark:text-red-400",
                          log.level === "warning" && "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
                          log.level === "success" && "bg-green-500/10 text-green-600 dark:text-green-400",
                          log.level === "info" && "bg-blue-500/10 text-blue-600 dark:text-blue-400",
                        )}
                      >
                        {log.level.toUpperCase()}
                      </span>
                      <span className="text-xs text-muted-foreground">{log.timestamp}</span>
                    </div>
                    <p className="text-foreground">{log.message}</p>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </div>
    </>
  )
}
