"use client"

import * as React from "react"
import { Moon, Sun, Terminal } from "lucide-react"
import { useTheme } from "next-themes"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { LogViewer } from "@/components/log-viewer"

export function DashboardHeader() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  const [showLogs, setShowLogs] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <>
      <header className="bg-background sticky top-0 z-10 flex h-14 shrink-0 items-center gap-2 border-b px-4">
        <div className="flex flex-1 items-center gap-2">
          <SidebarTrigger />
        </div>
        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center">
                  <div className="flex items-center gap-2 rounded-md border px-3 py-1.5 text-sm">
                    <div className="size-2 animate-pulse rounded-full bg-green-500" />
                    <span className="hidden font-medium sm:inline">Healthy</span>
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <div className="flex flex-col gap-1">
                  <div className="font-semibold">API Status</div>
                  <div className="flex justify-between gap-4 text-xs">
                    <span className="text-muted-foreground">Version:</span>
                    <span>0.1.0</span>
                  </div>
                  <div className="flex justify-between gap-4 text-xs">
                    <span className="text-muted-foreground">Status:</span>
                    <span className="text-green-600 dark:text-green-400">Healthy</span>
                  </div>
                  <div className="flex justify-between gap-4 text-xs">
                    <span className="text-muted-foreground">Timestamp:</span>
                    <span>2025-12-27 09:39:59</span>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Button variant="ghost" size="icon" onClick={() => setShowLogs(true)} className="size-9">
            <Terminal className="size-4" />
            <span className="sr-only">View Logs</span>
          </Button>

          <Button variant="ghost" size="icon" onClick={toggleTheme} className="size-9">
            {mounted && (
              <>
                {theme === "dark" ? (
                  <Sun className="size-4 rotate-0 scale-100 transition-all" />
                ) : (
                  <Moon className="size-4 rotate-0 scale-100 transition-all" />
                )}
              </>
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </header>

      <LogViewer open={showLogs} onOpenChange={setShowLogs} />
    </>
  )
}
