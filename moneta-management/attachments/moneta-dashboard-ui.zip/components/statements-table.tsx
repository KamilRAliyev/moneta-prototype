"use client"

import * as React from "react"
import { CheckCircle2 } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"

const statements = [
  {
    uploadedAt: "12/26/2025, 8:48:48 PM",
    filename: "Chase6490_Activity20240901_20251012_20251012.CSV",
    account: "Chase cred",
    size: "70.86 KB",
    rows: 1125,
    dateRange: "8/27/2024 - 9/30/2025",
    status: "uploaded",
    ingested: "1125/1125",
    fileExists: true,
  },
]

export function StatementsTable() {
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800)
    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Uploaded Statements</CardTitle>
          <CardDescription>View and manage your uploaded statements</CardDescription>
        </CardHeader>
        <div className="p-6 pt-0">
          <div className="flex flex-col gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex gap-4">
                <Skeleton className="h-10 flex-1" />
                <Skeleton className="h-10 w-32" />
              </div>
            ))}
          </div>
        </div>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Uploaded Statements</CardTitle>
        <CardDescription>View and manage your uploaded statements</CardDescription>
      </CardHeader>
      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Uploaded At</TableHead>
              <TableHead>Filename</TableHead>
              <TableHead>Account</TableHead>
              <TableHead>Size</TableHead>
              <TableHead>Rows</TableHead>
              <TableHead>Date Range</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Ingested</TableHead>
              <TableHead>File</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {statements.map((statement) => (
              <TableRow key={statement.filename}>
                <TableCell className="whitespace-nowrap">{statement.uploadedAt}</TableCell>
                <TableCell className="max-w-[300px] truncate font-medium">{statement.filename}</TableCell>
                <TableCell>{statement.account}</TableCell>
                <TableCell>{statement.size}</TableCell>
                <TableCell>{statement.rows}</TableCell>
                <TableCell className="whitespace-nowrap">{statement.dateRange}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-600 dark:text-blue-400">
                    {statement.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-green-600 dark:text-green-400">{statement.ingested}</span>
                </TableCell>
                <TableCell>
                  <CheckCircle2 className="size-4 text-green-600 dark:text-green-400" />
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="destructive" size="sm">
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  )
}
