<template>
  <div class="flex h-screen overflow-hidden">
    <!-- Sidebar -->
    <aside 
      :class="[
        'h-screen sticky top-0 border-r bg-card transition-all duration-300 ease-in-out flex flex-col',
        isCollapsed ? 'w-16' : 'w-64'
      ]"
    >
      <!-- Logo -->
      <div class="h-16 border-b flex items-center px-4">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold">
            M
          </div>
          <span v-if="!isCollapsed" class="font-semibold text-lg">Moneta</span>
        </div>
      </div>

      <!-- Navigation -->
      <nav class="flex-1 p-3 space-y-1">
        <router-link
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          class="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground"
          :class="{ 'bg-accent text-accent-foreground': route.path === item.path }"
        >
          <component :is="item.icon" class="w-5 h-5 flex-shrink-0" />
          <span v-if="!isCollapsed">{{ item.label }}</span>
        </router-link>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">
      <!-- Header -->
      <header class="h-16 border-b bg-card sticky top-0 z-10 flex items-center justify-between px-6">
        <button
          @click="toggleSidebar"
          class="p-2 rounded-md hover:bg-accent transition-colors"
        >
          <IconMenu class="w-5 h-5" />
        </button>

        <div class="flex items-center gap-3">
          <!-- Health Status -->
          <div class="relative group">
            <div class="p-2 rounded-md hover:bg-accent transition-colors cursor-pointer">
              <div :class="['w-3 h-3 rounded-full', healthStatusColor]"></div>
            </div>
            <div class="absolute right-0 top-full mt-2 w-64 bg-card border rounded-lg shadow-lg p-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Status:</span>
                  <span class="font-medium capitalize">{{ healthStatus }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Version:</span>
                  <span class="font-medium">{{ apiVersion }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Timestamp:</span>
                  <span class="font-medium">{{ apiTimestamp }}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Logs Button -->
          <button
            @click="toggleLogs"
            class="p-2 rounded-md hover:bg-accent transition-colors"
          >
            <IconFileText class="w-5 h-5" />
          </button>

          <!-- Theme Toggle -->
          <button
            @click="toggleTheme"
            class="p-2 rounded-md hover:bg-accent transition-colors"
          >
            <IconSun v-if="isDark" class="w-5 h-5 transition-transform duration-300 rotate-0 hover:rotate-180" />
            <IconMoon v-else class="w-5 h-5 transition-transform duration-300 rotate-0 hover:-rotate-180" />
          </button>
        </div>
      </header>

      <!-- Content Area -->
      <main class="flex-1 overflow-y-auto p-6">
        <slot />
      </main>
    </div>

    <!-- Log Viewer Panel -->
    <LogViewer :is-open="isLogsOpen" @close="toggleLogs" />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import LogViewer from './LogViewer.vue'
import IconHome from './icons/IconHome.vue'
import IconCreditCard from './icons/IconCreditCard.vue'
import IconFileText from './icons/IconFileText.vue'
import IconArrowLeftRight from './icons/IconArrowLeftRight.vue'
import IconMenu from './icons/IconMenu.vue'
import IconSun from './icons/IconSun.vue'
import IconMoon from './icons/IconMoon.vue'

const route = useRoute()
const isCollapsed = ref(false)
const isLogsOpen = ref(false)
const isDark = ref(false)

// Mock API health data
const healthStatus = ref('healthy')
const apiVersion = ref('0.1.0')
const apiTimestamp = ref('2025-12-27 09:39:59')

const healthStatusColor = computed(() => {
  const colors = {
    healthy: 'bg-green-500',
    warning: 'bg-yellow-500',
    error: 'bg-red-500'
  }
  return colors[healthStatus.value] || 'bg-gray-500'
})

const navItems = [
  { path: '/', label: 'Home', icon: IconHome },
  { path: '/accounts', label: 'Accounts', icon: IconCreditCard },
  { path: '/statements', label: 'Statements', icon: IconFileText },
  { path: '/transactions', label: 'Transactions', icon: IconArrowLeftRight },
]

const toggleSidebar = () => {
  isCollapsed.value = !isCollapsed.value
}

const toggleLogs = () => {
  isLogsOpen.value = !isLogsOpen.value
}

const toggleTheme = () => {
  isDark.value = !isDark.value
  localStorage.setItem('theme', isDark.value ? 'dark' : 'light')
  window.dispatchEvent(new CustomEvent('theme-change', { detail: { isDark: isDark.value } }))
}
</script>
