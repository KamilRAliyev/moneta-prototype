<template>
  <Transition
    enter-active-class="transition-transform duration-300 ease-out"
    enter-from-class="translate-x-full"
    enter-to-class="translate-x-0"
    leave-active-class="transition-transform duration-300 ease-in"
    leave-from-class="translate-x-0"
    leave-to-class="translate-x-full"
  >
    <div
      v-if="isOpen"
      class="fixed top-0 right-0 h-screen w-96 bg-card border-l shadow-2xl z-50 flex flex-col"
    >
      <!-- Header -->
      <div class="h-16 border-b flex items-center justify-between px-4">
        <h2 class="font-semibold text-lg">Logs</h2>
        <button @click="$emit('close')" class="p-2 rounded-md hover:bg-accent transition-colors">
          <IconX class="w-5 h-5" />
        </button>
      </div>

      <!-- Logs Content -->
      <div class="flex-1 overflow-y-auto p-4">
        <div class="space-y-2 font-mono text-xs">
          <div v-for="(log, index) in logs" :key="index" class="p-2 rounded bg-muted">
            <span class="text-muted-foreground">{{ log.timestamp }}</span>
            <span :class="getLogColor(log.level)" class="ml-2 font-semibold">{{ log.level }}</span>
            <div class="mt-1">{{ log.message }}</div>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div class="h-16 border-t flex items-center gap-2 px-4">
        <button
          @click="clearLogs"
          class="flex-1 px-4 py-2 text-sm font-medium rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors"
        >
          Clear
        </button>
        <button
          @click="forceRefresh"
          class="flex-1 px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          Force Refresh
        </button>
      </div>
    </div>
  </Transition>

  <!-- Backdrop -->
  <Transition
    enter-active-class="transition-opacity duration-300"
    enter-from-class="opacity-0"
    enter-to-class="opacity-100"
    leave-active-class="transition-opacity duration-300"
    leave-from-class="opacity-100"
    leave-to-class="opacity-0"
  >
    <div
      v-if="isOpen"
      @click="$emit('close')"
      class="fixed inset-0 bg-black/50 z-40"
    />
  </Transition>
</template>

<script setup>
import { ref } from 'vue'
import IconX from './icons/IconX.vue'

defineProps({
  isOpen: Boolean
})

defineEmits(['close'])

const logs = ref([
  { timestamp: '2025-12-27 09:39:59', level: 'INFO', message: 'Application started successfully' },
  { timestamp: '2025-12-27 09:40:12', level: 'INFO', message: 'Database connection established' },
  { timestamp: '2025-12-27 09:40:15', level: 'SUCCESS', message: 'Statement uploaded: Chase6490_Activity.csv' },
  { timestamp: '2025-12-27 09:40:18', level: 'INFO', message: 'Processing 1,125 transactions' },
  { timestamp: '2025-12-27 09:40:25', level: 'SUCCESS', message: 'All transactions ingested successfully' },
])

const getLogColor = (level) => {
  const colors = {
    INFO: 'text-blue-500',
    SUCCESS: 'text-green-500',
    WARNING: 'text-yellow-500',
    ERROR: 'text-red-500'
  }
  return colors[level] || 'text-foreground'
}

const clearLogs = () => {
  logs.value = []
}

const forceRefresh = () => {
  logs.value = [
    ...logs.value,
    { timestamp: new Date().toLocaleString(), level: 'INFO', message: 'Logs refreshed' }
  ]
}
</script>
