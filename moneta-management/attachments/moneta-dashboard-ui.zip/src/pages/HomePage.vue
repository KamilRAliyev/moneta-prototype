<template>
  <div class="max-w-7xl mx-auto">
    <div class="mb-8">
      <h1 class="text-3xl font-bold mb-2">Welcome to Moneta</h1>
      <p class="text-muted-foreground">Personal finance management application</p>
    </div>

    <div v-if="loading" class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <SkeletonLoader v-for="i in 3" :key="i">
        <div class="bg-card border rounded-lg p-6">
          <div class="h-4 bg-muted rounded w-1/2 mb-4"></div>
          <div class="h-8 bg-muted rounded w-3/4"></div>
        </div>
      </SkeletonLoader>
    </div>

    <div v-else class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="bg-card border rounded-lg p-6">
        <p class="text-sm text-muted-foreground mb-2">Total Accounts</p>
        <p class="text-3xl font-bold">{{ stats.accounts }}</p>
      </div>
      <div class="bg-card border rounded-lg p-6">
        <p class="text-sm text-muted-foreground mb-2">Statements Uploaded</p>
        <p class="text-3xl font-bold">{{ stats.statements }}</p>
      </div>
      <div class="bg-card border rounded-lg p-6">
        <p class="text-sm text-muted-foreground mb-2">Transactions</p>
        <p class="text-3xl font-bold">{{ stats.transactions.toLocaleString() }}</p>
      </div>
    </div>

    <div class="mt-8 bg-card border rounded-lg p-6">
      <h2 class="text-xl font-semibold mb-4">API Status</h2>
      <button
        @click="checkHealth"
        class="px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
      >
        Check Health
      </button>
      <div v-if="healthData" class="mt-4 space-y-2">
        <div class="flex items-center gap-2">
          <div :class="['w-3 h-3 rounded-full', healthData.status === 'healthy' ? 'bg-green-500' : 'bg-red-500']"></div>
          <span class="font-medium">Status: {{ healthData.status }}</span>
        </div>
        <p class="text-sm text-muted-foreground">Version: {{ healthData.version }}</p>
        <p class="text-sm text-muted-foreground">Timestamp: {{ healthData.timestamp }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import SkeletonLoader from '../components/SkeletonLoader.vue'

const loading = ref(true)
const stats = ref({
  accounts: 0,
  statements: 0,
  transactions: 0
})
const healthData = ref(null)

onMounted(() => {
  // Simulate loading
  setTimeout(() => {
    stats.value = {
      accounts: 1,
      statements: 1,
      transactions: 1125
    }
    loading.value = false
  }, 1000)
})

const checkHealth = () => {
  healthData.value = {
    status: 'healthy',
    version: '0.1.0',
    timestamp: '2025-12-27 09:39:59'
  }
  window.showToast({
    type: 'success',
    title: 'Health Check',
    message: 'API is healthy'
  })
}
</script>
