<template>
  <div class="max-w-7xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
      <h1 class="text-3xl font-bold">Transactions</h1>
      <div class="flex items-center gap-2">
        <button
          class="px-3 py-2 text-sm font-medium rounded-md border hover:bg-accent transition-colors flex items-center gap-2"
        >
          <SettingsIcon class="w-4 h-4" />
          Column Settings
        </button>
        <button
          class="px-3 py-2 text-sm font-medium rounded-md border border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors"
        >
          Remove All Transactions
        </button>
      </div>
    </div>

    <!-- Filters -->
    <div class="bg-card border rounded-lg p-4 mb-6">
      <div class="flex items-center gap-3">
        <div class="flex-shrink-0">
          <label class="block text-sm font-medium mb-2">Account</label>
          <select class="px-3 py-2 border rounded-md bg-background">
            <option>All Accounts</option>
            <option>Chase cred</option>
          </select>
        </div>
        <div class="flex-1"></div>
        <button
          class="px-3 py-2 text-sm font-medium rounded-md border hover:bg-accent transition-colors mt-6"
        >
          + Add Filter
        </button>
      </div>
    </div>

    <!-- Transactions Table -->
    <div class="bg-card border rounded-lg overflow-hidden">
      <div v-if="loading" class="p-6">
        <SkeletonLoader>
          <div class="space-y-3">
            <div v-for="i in 10" :key="i" class="h-12 bg-muted rounded"></div>
          </div>
        </SkeletonLoader>
      </div>

      <div v-else class="overflow-x-auto">
        <table class="w-full">
          <thead class="border-b bg-muted/50">
            <tr>
              <th class="text-left p-3 text-sm font-medium">Inserted At</th>
              <th class="text-left p-3 text-sm font-medium">Account</th>
              <th class="text-left p-3 text-sm font-medium">Statement</th>
              <th class="text-right p-3 text-sm font-medium">Amount</th>
              <th class="text-left p-3 text-sm font-medium">Category</th>
              <th class="text-left p-3 text-sm font-medium">Description</th>
              <th class="text-left p-3 text-sm font-medium">Post Date</th>
              <th class="text-left p-3 text-sm font-medium">Transaction Date</th>
              <th class="text-left p-3 text-sm font-medium">Type</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="transaction in transactions" :key="transaction.id" class="border-b last:border-0 hover:bg-muted/50 transition-colors">
              <td class="p-3 text-sm text-muted-foreground">{{ transaction.insertedAt }}</td>
              <td class="p-3 text-sm">{{ transaction.account }}</td>
              <td class="p-3 text-sm text-muted-foreground text-xs">{{ transaction.statement }}</td>
              <td class="p-3 text-sm font-medium text-right" :class="transaction.amount > 0 ? 'text-green-600' : ''">
                {{ transaction.amount }}
              </td>
              <td class="p-3 text-sm">
                <span v-if="transaction.category" class="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-muted">
                  {{ transaction.category }}
                </span>
                <span v-else class="text-muted-foreground">-</span>
              </td>
              <td class="p-3 text-sm">{{ transaction.description }}</td>
              <td class="p-3 text-sm text-muted-foreground">{{ transaction.postDate }}</td>
              <td class="p-3 text-sm text-muted-foreground">{{ transaction.transactionDate }}</td>
              <td class="p-3 text-sm">
                <span class="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-muted">
                  {{ transaction.type }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div v-if="!loading" class="border-t p-4 flex items-center justify-between">
        <p class="text-sm text-muted-foreground">
          Showing 1-{{ transactions.length }} of 1,125 transactions
        </p>
        <div class="flex items-center gap-2">
          <button class="px-3 py-1 text-sm border rounded-md hover:bg-accent transition-colors disabled:opacity-50" disabled>
            Previous
          </button>
          <button class="px-3 py-1 text-sm border rounded-md hover:bg-accent transition-colors">
            Next
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import SkeletonLoader from '../components/SkeletonLoader.vue'
import SettingsIcon from '../components/icons/SettingsIcon.vue'

const loading = ref(true)
const transactions = ref([])

onMounted(() => {
  setTimeout(() => {
    transactions.value = [
      {
        id: 1,
        insertedAt: '12/27/2025, 12:56:56 AM',
        account: 'Chase cred',
        statement: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        amount: 500,
        category: null,
        description: 'Payment Thank You-Mobile',
        postDate: '9/11/2024',
        transactionDate: '9/11/2024',
        type: 'Payment'
      },
      {
        id: 2,
        insertedAt: '12/27/2025, 12:56:56 AM',
        account: 'Chase cred',
        statement: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        amount: -24.54,
        category: 'Food & Drink',
        description: 'DD *DOORDASH KINGSTERI',
        postDate: '9/9/2024',
        transactionDate: '9/8/2024',
        type: 'Sale'
      },
      {
        id: 3,
        insertedAt: '12/27/2025, 12:56:56 AM',
        account: 'Chase cred',
        statement: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        amount: -25.96,
        category: 'Travel',
        description: 'UBER *TRIP',
        postDate: '9/15/2024',
        transactionDate: '9/14/2024',
        type: 'Sale'
      },
      {
        id: 4,
        insertedAt: '12/27/2025, 12:56:56 AM',
        account: 'Chase cred',
        statement: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        amount: -5.93,
        category: 'Food & Drink',
        description: 'TST* MACQUARIE NY CAFE',
        postDate: '9/12/2024',
        transactionDate: '9/11/2024',
        type: 'Sale'
      },
      {
        id: 5,
        insertedAt: '12/27/2025, 12:56:56 AM',
        account: 'Chase cred',
        statement: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        amount: -12.5,
        category: 'Groceries',
        description: 'SEVEN DAY CONVENIENCE IN',
        postDate: '9/9/2024',
        transactionDate: '9/7/2024',
        type: 'Sale'
      }
    ]
    loading.value = false
  }, 1000)
})
</script>
