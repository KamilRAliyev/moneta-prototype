<template>
  <div class="max-w-7xl mx-auto">
    <div class="mb-6 flex items-center justify-between">
      <h1 class="text-3xl font-bold">Accounts</h1>
      <button
        class="px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
      >
        Create Account
      </button>
    </div>

    <div class="bg-card border rounded-lg overflow-hidden">
      <div v-if="loading" class="p-6">
        <SkeletonLoader>
          <div class="space-y-4">
            <div v-for="i in 3" :key="i" class="h-12 bg-muted rounded"></div>
          </div>
        </SkeletonLoader>
      </div>

      <table v-else class="w-full">
        <thead class="border-b bg-muted/50">
          <tr>
            <th class="text-left p-4 text-sm font-medium">Name</th>
            <th class="text-left p-4 text-sm font-medium">Institution</th>
            <th class="text-left p-4 text-sm font-medium">Currency</th>
            <th class="text-left p-4 text-sm font-medium">Type</th>
            <th class="text-left p-4 text-sm font-medium">Economic Area</th>
            <th class="text-left p-4 text-sm font-medium">Date Lock</th>
            <th class="text-right p-4 text-sm font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="account in accounts" :key="account.id" class="border-b last:border-0 hover:bg-muted/50 transition-colors">
            <td class="p-4">{{ account.name }}</td>
            <td class="p-4 text-muted-foreground">{{ account.institution }}</td>
            <td class="p-4 text-muted-foreground">{{ account.currency }}</td>
            <td class="p-4 text-muted-foreground">{{ account.type }}</td>
            <td class="p-4 text-muted-foreground">{{ account.economicArea }}</td>
            <td class="p-4 text-muted-foreground">{{ account.dateLock || 'No date lock' }}</td>
            <td class="p-4">
              <div class="flex items-center justify-end gap-2">
                <button class="px-3 py-1 text-sm rounded-md border hover:bg-accent transition-colors">
                  Edit
                </button>
                <button class="px-3 py-1 text-sm rounded-md border border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors">
                  Delete
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-if="!loading && accounts.length === 0" class="p-12 text-center">
        <div class="text-muted-foreground mb-4">
          <IconCreditCard class="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p class="text-lg font-medium">No accounts yet</p>
          <p class="text-sm">Create your first account to get started</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import SkeletonLoader from '../components/SkeletonLoader.vue'
import IconCreditCard from '../components/icons/IconCreditCard.vue'

const loading = ref(true)
const accounts = ref([])

onMounted(() => {
  setTimeout(() => {
    accounts.value = [
      {
        id: 1,
        name: 'Chase cred',
        institution: 'Chase',
        currency: 'USD',
        type: 'Credit Card',
        economicArea: 'us',
        dateLock: 'No date lock'
      }
    ]
    loading.value = false
  }, 800)
})
</script>
