<template>
  <div class="max-w-7xl mx-auto">
    <div class="mb-6">
      <h1 class="text-3xl font-bold mb-2">Statements</h1>
      <p class="text-muted-foreground">Upload and manage CSV statement files for your accounts</p>
    </div>

    <!-- Upload Card -->
    <div class="bg-card border rounded-lg p-6 mb-6">
      <h2 class="text-lg font-semibold mb-4">Upload Statement</h2>
      
      <div class="mb-4">
        <label class="block text-sm font-medium mb-2">
          Account <span class="text-destructive">*</span>
        </label>
        <select class="w-full px-3 py-2 border rounded-md bg-background">
          <option>Select an account...</option>
          <option>Chase cred</option>
        </select>
      </div>

      <div class="mb-4">
        <label class="block text-sm font-medium mb-2">
          CSV File <span class="text-destructive">*</span>
        </label>
        <div
          class="border-2 border-dashed rounded-lg p-12 text-center cursor-pointer hover:border-primary transition-colors"
          @dragover.prevent
          @drop.prevent="handleDrop"
        >
          <UploadIcon class="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
          <p class="text-sm font-medium mb-1">Click to upload or drag and drop</p>
          <p class="text-xs text-muted-foreground">CSV files only (max 50MB)</p>
        </div>
      </div>

      <button
        class="w-full px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
      >
        Upload Statement
      </button>
    </div>

    <!-- Statements Table -->
    <div class="bg-card border rounded-lg overflow-hidden">
      <div class="p-4 border-b flex items-center justify-between">
        <h2 class="text-lg font-semibold">Uploaded Statements</h2>
        <button
          v-if="statements.length > 0"
          class="px-3 py-1 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          Ingest All
        </button>
      </div>

      <div v-if="loading" class="p-6">
        <SkeletonLoader>
          <div class="space-y-4">
            <div v-for="i in 2" :key="i" class="h-16 bg-muted rounded"></div>
          </div>
        </SkeletonLoader>
      </div>

      <table v-else-if="statements.length > 0" class="w-full">
        <thead class="border-b bg-muted/50">
          <tr>
            <th class="text-left p-4 text-sm font-medium">Uploaded At</th>
            <th class="text-left p-4 text-sm font-medium">Filename</th>
            <th class="text-left p-4 text-sm font-medium">Account</th>
            <th class="text-left p-4 text-sm font-medium">Size</th>
            <th class="text-left p-4 text-sm font-medium">Rows</th>
            <th class="text-left p-4 text-sm font-medium">Date Range</th>
            <th class="text-left p-4 text-sm font-medium">Status</th>
            <th class="text-left p-4 text-sm font-medium">Ingested</th>
            <th class="text-right p-4 text-sm font-medium">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="statement in statements" :key="statement.id" class="border-b last:border-0 hover:bg-muted/50 transition-colors">
            <td class="p-4 text-sm">{{ statement.uploadedAt }}</td>
            <td class="p-4 text-sm font-medium">{{ statement.filename }}</td>
            <td class="p-4 text-sm text-muted-foreground">{{ statement.account }}</td>
            <td class="p-4 text-sm text-muted-foreground">{{ statement.size }}</td>
            <td class="p-4 text-sm text-muted-foreground">{{ statement.rows }}</td>
            <td class="p-4 text-sm text-muted-foreground">{{ statement.dateRange }}</td>
            <td class="p-4">
              <span :class="[
                'inline-flex items-center px-2 py-1 text-xs font-medium rounded-full',
                statement.status === 'uploaded' ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300' : 'bg-green-100 dark:bg-green-950 text-green-700 dark:text-green-300'
              ]">
                {{ statement.status }}
              </span>
            </td>
            <td class="p-4 text-sm">
              <span :class="statement.ingested ? 'text-green-600' : 'text-muted-foreground'">
                {{ statement.ingested }}
              </span>
            </td>
            <td class="p-4">
              <div class="flex items-center justify-end gap-2">
                <button class="p-1 rounded hover:bg-accent transition-colors">
                  <CheckIcon class="w-4 h-4 text-green-600" />
                </button>
                <button class="p-1 rounded hover:bg-accent transition-colors">
                  <TrashIcon class="w-4 h-4 text-destructive" />
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-else class="p-12 text-center">
        <IconFileText class="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-50" />
        <p class="text-lg font-medium text-muted-foreground mb-1">No statements uploaded</p>
        <p class="text-sm text-muted-foreground">Upload your first CSV statement to get started</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import SkeletonLoader from '../components/SkeletonLoader.vue'
import IconFileText from '../components/icons/IconFileText.vue'
import UploadIcon from '../components/icons/UploadIcon.vue'
import CheckIcon from '../components/icons/CheckIcon.vue'
import TrashIcon from '../components/icons/TrashIcon.vue'

const loading = ref(true)
const statements = ref([])

onMounted(() => {
  setTimeout(() => {
    statements.value = [
      {
        id: 1,
        uploadedAt: '12/26/2025, 8:48:48 PM',
        filename: 'Chase6490_Activity20240901_20251012_20251012.CSV',
        account: 'Chase cred',
        size: '70.86 KB',
        rows: '1,125',
        dateRange: '8/27/2024 ~ 9/30/2025',
        status: 'uploaded',
        ingested: 'Ingested (1125/1125)'
      }
    ]
    loading.value = false
  }, 800)
})

const handleDrop = (e) => {
  const files = e.dataTransfer.files
  if (files.length > 0) {
    window.showToast({
      type: 'info',
      title: 'File Selected',
      message: `${files[0].name} ready to upload`
    })
  }
}
</script>
