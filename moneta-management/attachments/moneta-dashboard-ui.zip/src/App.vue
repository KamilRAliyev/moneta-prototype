<template>
  <div :class="{ 'dark': isDark }">
    <div class="min-h-screen bg-background text-foreground">
      <DashboardLayout>
        <router-view />
      </DashboardLayout>
      <ToastContainer />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import DashboardLayout from './components/DashboardLayout.vue'
import ToastContainer from './components/ToastContainer.vue'

const isDark = ref(false)

onMounted(() => {
  const savedTheme = localStorage.getItem('theme')
  if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    isDark.value = true
  }
  
  window.addEventListener('theme-change', (e) => {
    isDark.value = e.detail.isDark
  })
})
</script>
