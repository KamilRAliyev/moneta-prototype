import { createApp } from "vue"
import { createRouter, createWebHistory } from "vue-router"
import "./style.css"
import App from "./App.vue"

import HomePage from "./pages/HomePage.vue"
import AccountsPage from "./pages/AccountsPage.vue"
import StatementsPage from "./pages/StatementsPage.vue"
import TransactionsPage from "./pages/TransactionsPage.vue"

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", component: HomePage },
    { path: "/accounts", component: AccountsPage },
    { path: "/statements", component: StatementsPage },
    { path: "/transactions", component: TransactionsPage },
  ],
})

const app = createApp(App)
app.use(router)
app.mount("#app")
